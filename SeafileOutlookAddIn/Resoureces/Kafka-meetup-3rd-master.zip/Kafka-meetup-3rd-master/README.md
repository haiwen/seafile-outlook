# 第三次Kafka Meetup活动

本库存的是第三次Kafka Meetup活动PPT资料。更多关于大数据的相关文章、资讯以及PPT资料请访问[过往记忆](https://www.iteblog.com)，

- 日程 => [官方日程](https://www.meetup.com/de-DE/Beijing-Kafka-Meetup/events/238136716/)
- 备份访问 => [第三次Kafka Meetup活动](http://mp.weixin.qq.com/s/k0kW9mNLHkns39SGC3dzlg)

关注 iteblog_hadoop 公众号 或 [过往记忆](https://www.iteblog.com) 及时获取大数据相关信息。

![第三次Kafka Meetup活动](resources/iteblog_hadoop.jpg)

